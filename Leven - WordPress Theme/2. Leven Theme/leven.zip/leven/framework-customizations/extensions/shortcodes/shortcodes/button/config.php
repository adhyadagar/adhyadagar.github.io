<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array();

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Button', 'leven' ),
	'description' => esc_html__( 'Add a Button', 'leven' ),
	'tab'         => esc_html__( 'Leven Elements', 'leven' ),
	'popup_size' => 'small'
);
