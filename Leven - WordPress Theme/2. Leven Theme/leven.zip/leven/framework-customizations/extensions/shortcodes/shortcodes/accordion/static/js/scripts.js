(function($) { 
"use strict";
    $(document).ready(function($){
        $( ".fw-accordion" ).accordion({
            heightStyle: "content"
        });
    });
})(jQuery);
