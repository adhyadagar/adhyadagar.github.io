<?php if (!defined('FW')) die('Forbidden');

$cfg = array(
	'page_builder' => array(
		'tab'         => esc_html__('Layout Elements', 'leven'),
		'title'       => esc_html__('Column', 'leven'),
		'popup_size'  => 'small',
		'type'        => 'column'
	)
);