<?php if (!defined('FW')) die('Forbidden');
/**
 * @var string $uri Demo directory url
 */

$manifest = array();
$manifest['title'] = esc_html__('Leven Theme Demo Dark', 'leven');
$manifest['screenshot'] = $uri . '/screenshot.png';
$manifest['preview_link'] = 'https://lmpixels.com/wp/leven-wp/dark/';