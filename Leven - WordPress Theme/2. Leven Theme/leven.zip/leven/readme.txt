lmpixels 

http://themeforest.net/user/lmpixels